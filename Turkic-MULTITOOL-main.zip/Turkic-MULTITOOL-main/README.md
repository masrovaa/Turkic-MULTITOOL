








Developed in Python, by Masrova or Veyko. ( I have two )

Tool in English.

Available on Windows and Linux.

No malware or backdoor.

Frequently updated.

Free for everyone.

The tools include : Scanning, Osint, Gen, Discord, And more...









































If you want to run the tool you need these requirements :

pip install colorama
pip install Fore
pip install Style
pip install os
pip install socket
pip install sys
pip install requests
pip install pywhatkit
pip install pyshorteners
pip install base64
pip install qrcode
pip install sqlite3
pip install platform
pip install time
pip install datetime
pip install random
pip install faker
pip install Faker
pip install sample
pip install PyPDF2
